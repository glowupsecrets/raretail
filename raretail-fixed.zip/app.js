// Raretail Presentation Interactive Features

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all interactive features
    initNavigation();
    initAnimatedCounters();
    initScrollAnimations();
    initModalFunctionality();
    initHoverEffects();
    initProgressiveDisclosure();
});

// Navigation functionality
function initNavigation() {
    const navbar = document.getElementById('navbar');
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('section[id]');
    
    // Smooth scrolling for navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            
            if (targetSection) {
                const offsetTop = targetSection.offsetTop - 70; // Account for fixed navbar
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Navbar scroll effects and active section highlighting
    window.addEventListener('scroll', function() {
        // Add scrolled class to navbar
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
        
        // Highlight active section in navigation
        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            const sectionHeight = section.clientHeight;
            
            if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === '#' + current) {
                link.classList.add('active');
            }
        });
    });
}

// Animated counters for statistics
function initAnimatedCounters() {
    const counters = document.querySelectorAll('.stat-number[data-target]');
    const counterOptions = {
        threshold: 0.3,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const counterObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counter = entry.target;
                const target = parseFloat(counter.getAttribute('data-target'));
                animateCounter(counter, target);
                counterObserver.unobserve(counter);
            }
        });
    }, counterOptions);
    
    counters.forEach(counter => {
        counterObserver.observe(counter);
    });
}

function animateCounter(element, target) {
    let current = 0;
    const increment = target / 100;
    const duration = 2000; // 2 seconds
    const stepTime = duration / 100;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        
        // Format the number display
        let displayValue;
        if (target >= 10) {
            displayValue = current.toFixed(1);
        } else {
            displayValue = current.toFixed(2);
        }
        
        element.textContent = displayValue;
    }, stepTime);
}

// Scroll animations for sections and cards
function initScrollAnimations() {
    const animatedElements = document.querySelectorAll('.summary-card, .pillar-card, .channel-card, .persona-card, .timeline-item');
    
    const animationOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const animationObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                entry.target.style.transition = 'all 0.6s ease';
            }
        });
    }, animationOptions);
    
    // Initially hide elements and set up animation
    animatedElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        animationObserver.observe(element);
    });
    
    // Timeline items get staggered animation
    const timelineItems = document.querySelectorAll('.timeline-item');
    timelineItems.forEach((item, index) => {
        item.style.animationDelay = `${index * 0.2}s`;
    });
}

// Modal functionality for chart viewing
function initModalFunctionality() {
    const modal = document.getElementById('chart-modal');
    const modalTitle = document.getElementById('modal-chart-title');
    const modalContent = document.getElementById('modal-chart-content');
    const closeModal = document.querySelector('.close-modal');
    const chartContainers = document.querySelectorAll('.chart-placeholder');
    
    // Chart data for modal display
    const chartData = {
        'market-opportunity': {
            title: 'Global Civet Coffee Market Overview',
            content: `
                <div class="modal-chart-details">
                    <div class="chart-metric">
                        <h4>Current Market Size</h4>
                        <p class="metric-value">$7.8 Billion</p>
                        <p class="metric-desc">Global luxury coffee market value in 2024</p>
                    </div>
                    <div class="chart-metric">
                        <h4>Projected Growth</h4>
                        <p class="metric-value">$10.2 Billion by 2030</p>
                        <p class="metric-desc">5.6% CAGR over the next 6 years</p>
                    </div>
                    <div class="chart-metric">
                        <h4>Regional Breakdown</h4>
                        <ul class="region-breakdown">
                            <li>Asia-Pacific: 45% market share, 6.2% growth</li>
                            <li>Europe: 35% market share, 5.1% growth</li>
                            <li>North America: 15% market share, 4.8% growth</li>
                        </ul>
                    </div>
                </div>
            `
        },
        'consumer-insights': {
            title: 'Luxury Coffee Consumer Analysis',
            content: `
                <div class="modal-chart-details">
                    <div class="chart-metric">
                        <h4>Primary Demographics</h4>
                        <div class="demo-breakdown">
                            <p><strong>35-44 years:</strong> 32% of market, $125K average income</p>
                            <p><strong>25-34 years:</strong> 28% of market, $95K average income</p>
                            <p><strong>45-54 years:</strong> 25% of market, $145K average income</p>
                            <p><strong>55-64 years:</strong> 15% of market, $155K average income</p>
                        </div>
                    </div>
                    <div class="chart-metric">
                        <h4>Key Target Cities</h4>
                        <ul class="city-breakdown">
                            <li>New York: 9.2 potential score, $295 annual spend</li>
                            <li>San Francisco: 8.9 potential score, $295 annual spend</li>
                            <li>London: 8.8 potential score, $245 annual spend</li>
                            <li>Paris: 8.5 potential score, $230 annual spend</li>
                        </ul>
                    </div>
                </div>
            `
        },
        'brand-positioning': {
            title: 'Competitive Positioning Analysis',
            content: `
                <div class="modal-chart-details">
                    <div class="chart-metric">
                        <h4>Market Positioning</h4>
                        <div class="positioning-breakdown">
                            <div class="competitor-detail">
                                <strong>Black Ivory Coffee:</strong> $3,000/lb - Ultra-Luxury segment
                            </div>
                            <div class="competitor-detail highlight">
                                <strong>Raretail Civet Coffee:</strong> $1,000/lb - Luxury segment (Our Position)
                            </div>
                            <div class="competitor-detail">
                                <strong>Blue Bottle Coffee:</strong> $50/lb - Premium segment
                            </div>
                            <div class="competitor-detail">
                                <strong>Nespresso:</strong> $40/lb - Mass Premium segment
                            </div>
                        </div>
                    </div>
                    <div class="chart-metric">
                        <h4>Competitive Advantages</h4>
                        <ul class="advantage-list">
                            <li>Only ethical civet coffee from India</li>
                            <li>150-year Coorg coffee heritage</li>
                            <li>Premium but accessible luxury positioning</li>
                            <li>Forest conservation sustainability story</li>
                        </ul>
                    </div>
                </div>
            `
        },
        'financial-projections': {
            title: 'Financial Projections Dashboard',
            content: `
                <div class="modal-chart-details">
                    <div class="chart-metric">
                        <h4>Revenue Projections</h4>
                        <div class="financial-breakdown">
                            <div class="year-projection">
                                <strong>Year 1:</strong> $2.5M revenue, 2,500 lbs volume
                            </div>
                            <div class="year-projection">
                                <strong>Year 2:</strong> $6.8M revenue, 5,800 lbs volume
                            </div>
                            <div class="year-projection highlight">
                                <strong>Year 3:</strong> $12.5M revenue, 8,500 lbs volume
                            </div>
                        </div>
                    </div>
                    <div class="chart-metric">
                        <h4>Channel Performance</h4>
                        <ul class="channel-breakdown">
                            <li>Direct-to-Consumer: 40% share, 75% margin</li>
                            <li>Luxury Hotels: 25% share, 68% margin</li>
                            <li>High-end Retail: 20% share, 58% margin</li>
                            <li>B2B Partnerships: 15% share, 52% margin</li>
                        </ul>
                    </div>
                </div>
            `
        }
    };
    
    // Add click handlers to chart containers
    chartContainers.forEach(container => {
        container.style.cursor = 'pointer';
        container.addEventListener('click', function() {
            const section = this.closest('section').id;
            const data = chartData[section];
            
            if (data) {
                modalTitle.textContent = data.title;
                modalContent.innerHTML = data.content;
                modal.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
            }
        });
        
        // Add hover effect to indicate clickability
        container.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.02)';
            this.style.transition = 'transform 0.3s ease';
        });
        
        container.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
    
    // Close modal functionality
    function closeModalHandler() {
        modal.classList.add('hidden');
        document.body.style.overflow = 'auto';
    }
    
    closeModal.addEventListener('click', closeModalHandler);
    
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModalHandler();
        }
    });
    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
            closeModalHandler();
        }
    });
}

// Hover effects for interactive elements
function initHoverEffects() {
    // Enhanced hover effects for cards
    const cards = document.querySelectorAll('.summary-card, .pillar-card, .channel-card, .persona-card, .info-card');
    
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px) scale(1.02)';
            this.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.15)';
            this.style.transition = 'all 0.3s ease';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.1)';
        });
    });
    
    // Hover effects for statistics
    const statNumbers = document.querySelectorAll('.stat-number, .highlight-number');
    statNumbers.forEach(stat => {
        stat.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.1)';
            this.style.transition = 'transform 0.3s ease';
        });
        
        stat.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
}

// Progressive disclosure for detailed information
function initProgressiveDisclosure() {
    // Create expandable sections for detailed information
    const expandableSections = [
        {
            trigger: '.summary-card',
            content: 'detailed-info',
            info: {
                0: 'The global luxury coffee market represents a significant opportunity, with premium segments showing consistent growth despite economic fluctuations.',
                1: 'Our target markets show strong purchasing power and growing interest in ethical, premium coffee experiences.',
                2: 'Conservative projections based on market penetration rates and premium positioning strategy.'
            }
        }
    ];
    
    // Add click handlers for expandable content
    document.querySelectorAll('.summary-card').forEach((card, index) => {
        const detailInfo = expandableSections[0].info[index];
        if (detailInfo) {
            card.addEventListener('click', function() {
                // Check if detail is already shown
                let existingDetail = this.querySelector('.detail-content');
                
                if (existingDetail) {
                    existingDetail.remove();
                } else {
                    const detailDiv = document.createElement('div');
                    detailDiv.className = 'detail-content';
                    detailDiv.style.cssText = `
                        margin-top: 1rem;
                        padding: 1rem;
                        background: rgba(27, 67, 50, 0.05);
                        border-radius: 6px;
                        font-size: 0.9rem;
                        line-height: 1.6;
                        color: #8B4513;
                        animation: fadeIn 0.3s ease;
                    `;
                    detailDiv.textContent = detailInfo;
                    this.appendChild(detailDiv);
                }
            });
            
            // Add cursor pointer to indicate clickability
            card.style.cursor = 'pointer';
        }
    });
}

// Utility function for smooth scrolling to sections
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        const offsetTop = section.offsetTop - 70;
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });
    }
}

// Add CSS for modal chart details
const modalStyles = document.createElement('style');
modalStyles.textContent = `
    .modal-chart-details {
        display: grid;
        gap: 2rem;
    }
    
    .chart-metric {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 8px;
        border-left: 4px solid #D4AF37;
    }
    
    .chart-metric h4 {
        color: #1B4332;
        margin-bottom: 1rem;
        font-size: 1.25rem;
    }
    
    .metric-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: #D4AF37;
        margin-bottom: 0.5rem;
    }
    
    .metric-desc {
        color: #8B4513;
        font-size: 0.9rem;
        line-height: 1.6;
    }
    
    .region-breakdown,
    .city-breakdown,
    .channel-breakdown,
    .advantage-list {
        list-style: none;
        padding: 0;
    }
    
    .region-breakdown li,
    .city-breakdown li,
    .channel-breakdown li,
    .advantage-list li {
        padding: 0.5rem 0;
        border-bottom: 1px solid rgba(27, 67, 50, 0.1);
    }
    
    .demo-breakdown p,
    .competitor-detail,
    .year-projection {
        padding: 0.75rem;
        margin-bottom: 0.5rem;
        background: white;
        border-radius: 6px;
        border: 1px solid rgba(27, 67, 50, 0.1);
    }
    
    .competitor-detail.highlight,
    .year-projection.highlight {
        border-color: #D4AF37;
        background: rgba(212, 175, 55, 0.1);
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .detail-content {
        animation: fadeIn 0.3s ease;
    }
`;

document.head.appendChild(modalStyles);

// Initialize everything when DOM is ready
console.log('Raretail Presentation Interactive Features Loaded');